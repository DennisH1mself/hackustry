# Hackustry
First Mindustry cheat mod ever made.

### Some clarifications
At this point this mod isn't really a cheat mod anymore. it has became a large testing and utility mod (with a messy codebase). you still can cheat using it, and cheating isn't always bad, and it was known as *the* cheat mod before which is the reason i'm labeling it "cheat mod" here. also i'll port this mod to [groovy](https://groovy-lang.org/) because ~~javascript will be getting limited again in mindustry 7.0.~~ i feel like it. (also js got unlimited again)

## Features
### Mindustry v8 update
- Supports Mindustry build 159+
- Hackusated Conveyor with complete v8 animation/blending sprites
- Instant high-throughput Hackusated Junction for crossed conveyor lines
- Hackusated Walls remain indestructible during combat
- Hackusated conveyors, junctions, and walls build and deconstruct instantly

### Finished
- Hackusated Conveyors (ported from v1)
- Instant Hackusated Junction
- Hackusated Walls (ported from v2)
- OP Turrets (from v3)
- Removed reconstructor costs (from v3)
- Cursed Mode (v3)
- Power Source Fix (v3)
- Launch Anywhere
- Discord Rich Presence
- Informative Title Bar
- Content Menu
    * Change build visibility of blocks (from v3)
    * Lock/Unlock/Temporarily Unlock content (from v3)
    * Change some stats
- World Options Menu
    * Change some common world options (e.g infiniteResources, editor, canGameOver...)
    * Change unit cap (improved from v3)
- Transform Menu
    * Transform into any unit you want
- New Configuration UI
    * Hackustry settings button that opens the UI where everything is controlled from
    * Features stay upon game restarts
    * Import/Export configuration
### In Progress/Not Happening
- Account System
    * Save names and UUID to quickly swap between
    * Possibly save unlocks/saves/features
    * In progress (probably will be in the groovy version)
- Unit Factory
    * no, already added in v7
- Port to Groovy
    * in progress (definitely happening)
    * will improve code quality
    * will also fix the code being too messy
    * groovy closures are amazing
- Add Bundle Support
    * translatable cheats wow
    * i mean it would help
    * most likely with the groovy version

## Credits
* Some people who helped me with the code while making the large v4 update:
    - [GlennFolker](https://github.com/GlennFolker/)
    - [sk7725](https://github.com/sk7725)
    - [catsz](https://github.com/catsz/)
* Idea contributors/inspiration for features
    - Some inspiration from [sk7725](https://github.com/sk7725)
    - Stat Editor Menu idea by [NiChrosia](https://github.com/NiChrosia/)
    - Launch Anywhere idea by [ThatOneBepis](https://github.com/ThatOneBepis/)
    - Transform Menu idea by [Prosta4okua](https://github.com/Prosta4okua)
    - Some miscellaneous ideas by [AnOreo1](https://github.com/AnOreo1/)
    - I forgot what they are but [Sh1penfire](https://github.com/Sh1penfire/) also suggested some stuff
