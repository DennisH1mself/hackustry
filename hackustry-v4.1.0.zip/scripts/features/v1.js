// Content must be created while this mod is the active loading context. Creating
// it from ContentInitEvent is too late in v8 and loses the mod namespace.
const hjunction = extend(Junction, "hackusated-junction", {
    localizedName: "Hackusated Junction",
    description: "Crosses item streams with no transit delay.",
    category: Category.distribution,
    requirements: ItemStack.empty,
    buildVisibility: BuildVisibility.hidden,
    inEditor: false,
    health: 99999,
    speed: 0,
    capacity: 64,
    displayedSpeed: 60,
    alwaysUnlocked: true
});

const hconv = extend(Conveyor, "hackusated-conveyor", {
    localizedName: "Hackusated Conveyor",
    description: "Moves items effectively instantly. Also launches units at absurd speed.",
    category: Category.distribution,
    requirements: ItemStack.empty,
    buildVisibility: BuildVisibility.hidden,
    inEditor: false,
    health: 99999,
    speed: 99999,
    displayedSpeed: 99999,
    junctionReplacement: hjunction,
    alwaysUnlocked: true
});

function setVisible(block, visible){
    block.inEditor = visible;
    block.buildVisibility = visible ? BuildVisibility.shown : BuildVisibility.hidden;
}

module.exports = add => {
    add("hackusated-conveyor", true, enabled => setVisible(hconv, enabled));
    add("hackusated-junction", true, enabled => setVisible(hjunction, enabled));
};
